<?php
//Celsius Value
$celsius = 32;

// Convert
$fahrenheit = ($celsius * 9/5) + 32;

printf("The Fahrenheit temperature is: %.2f", $fahrenheit);

?>
